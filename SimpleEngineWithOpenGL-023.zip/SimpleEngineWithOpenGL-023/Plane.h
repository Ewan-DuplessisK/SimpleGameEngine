#pragma once
#include "Actor.h"
class Plane : public Actor
{
public:
	Plane();
};

