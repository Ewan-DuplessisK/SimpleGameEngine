#include "Rectangle.h"

const Rectangle Rectangle::nullRect{ 0.f, 0.f, 0.f, 0.f };
